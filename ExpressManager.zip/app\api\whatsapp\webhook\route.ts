import { prisma } from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

type PayloadEvolution = {
  event?: string;
  instance?: string;
  data?: {
    key?: {
      remoteJid?: string;
      fromMe?: boolean;
      id?: string;
    };
    pushName?: string;
    message?: {
      conversation?: string;
      extendedTextMessage?: {
        text?: string;
      };
    };
    messageType?: string;
  };
};

function extrairMensagem(payload: PayloadEvolution) {
  return (
    payload.data?.message?.conversation?.trim() ||
    payload.data?.message?.extendedTextMessage?.text?.trim() ||
    ""
  );
}

function extrairTelefone(remoteJid: string | undefined) {
  if (!remoteJid) {
    return "";
  }

  return remoteJid.split("@")[0].replace(/\D/g, "");
}

export async function GET() {
  return NextResponse.json({
    status: "ok",
    mensagem: "Webhook do WhatsApp funcionando.",
  });
}

export async function POST(request: NextRequest) {
  try {
    const payload = (await request.json()) as PayloadEvolution;

    if (payload.event !== "messages.upsert") {
      return NextResponse.json({
        recebido: true,
        ignorado: true,
        motivo: "Evento não processado.",
      });
    }

    /*
     * Por enquanto, mensagens enviadas por você continuam ignoradas.
     * A captura das respostas humanas será implementada depois que
     * o recebimento das mensagens dos clientes estiver validado.
     */
    if (payload.data?.key?.fromMe) {
      return NextResponse.json({
        recebido: true,
        ignorado: true,
        motivo: "Mensagem enviada pelo próprio WhatsApp.",
      });
    }

    const remoteJid = payload.data?.key?.remoteJid;

    if (remoteJid?.endsWith("@g.us")) {
      return NextResponse.json({
        recebido: true,
        ignorado: true,
        motivo: "Mensagem de grupo.",
      });
    }

    const mensagem = extrairMensagem(payload);
    const telefoneRemetente = extrairTelefone(remoteJid);
    const mensagemId = payload.data?.key?.id?.trim() || null;
    const nomeExibicao = payload.data?.pushName?.trim() || null;
    const instance = payload.instance || process.env.EVOLUTION_INSTANCE || "express-manager";

    if (!mensagem || !telefoneRemetente) {
      return NextResponse.json({
        recebido: true,
        ignorado: true,
        motivo: "Mensagem de texto ou telefone não encontrados.",
      });
    }

    /*
     * A Evolution pode reenviar o mesmo evento.
     * O idExterno impede que a mesma mensagem seja salva duas vezes.
     */
    if (mensagemId) {
      const mensagemExistente = await prisma.mensagemAtendimento.findUnique({
        where: {
          idExterno: mensagemId,
        },
        select: {
          id: true,
          conversaId: true,
        },
      });

      if (mensagemExistente) {
        return NextResponse.json({
          recebido: true,
          salvo: true,
          duplicado: true,
          motivo: "Mensagem já registrada.",
        });
      }
    }

    const telefoneNormalizado = telefoneRemetente;
    const agora = new Date();

    const resultado = await prisma.$transaction(async (tx) => {
      let conversa = await tx.conversaAtendimento.findFirst({
        where: {
          canal: "WHATSAPP",
          telefoneNormalizado,
          ativo: true,
        },
        orderBy: {
          updatedAt: "desc",
        },
      });

      if (!conversa) {
        conversa = await tx.conversaAtendimento.create({
          data: {
            canal: "WHATSAPP",
            telefoneRemetente,
            telefoneNormalizado,
            nomeExibicao,
            status: "ABERTA",
            naoLidas: 1,
            ativo: true,
            ultimaMensagemEm: agora,
          },
        });
      } else {
        conversa = await tx.conversaAtendimento.update({
          where: {
            id: conversa.id,
          },
          data: {
            telefoneRemetente,
            nomeExibicao: nomeExibicao || conversa.nomeExibicao,
            status: conversa.status === "ENCERRADA" ? "ABERTA" : conversa.status,
            naoLidas: {
              increment: 1,
            },
            ultimaMensagemEm: agora,
          },
        });
      }

      const mensagemSalva = await tx.mensagemAtendimento.create({
        data: {
          conversaId: conversa.id,
          autor: "CLIENTE",
          direcao: "ENTRADA",
          tipo: "TEXTO",
          conteudo: mensagem,
          idExterno: mensagemId,
          enviadaEm: agora,
          metadata: {
            instance,
            remoteJid,
            pushName: nomeExibicao,
            messageType: payload.data?.messageType || null,
          },
        },
      });

      return {
        conversa,
        mensagem: mensagemSalva,
      };
    });

    console.log("\n========== MENSAGEM SALVA ==========");
    console.log({
      instance,
      nome: nomeExibicao,
      telefoneRemetente,
      conversaId: resultado.conversa.id,
      mensagemId: resultado.mensagem.id,
      conteudo: mensagem,
    });
    console.log("====================================\n");

    return NextResponse.json({
      recebido: true,
      salvo: true,
      conversaAtualizada: true,
      respostaAutomaticaEnviada: false,
    });
  } catch (error) {
    console.error("Erro ao processar webhook da Evolution:", error);

    return NextResponse.json(
      {
        recebido: false,
        erro: error instanceof Error ? error.message : "Erro ao processar webhook.",
      },
      { status: 500 }
    );
  }
}
