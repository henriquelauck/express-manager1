import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const conversas = await prisma.conversaAtendimento.findMany({
      where: {
        ativo: true,
      },
      include: {
        cliente: {
          select: {
            id: true,
            nome: true,
            telefone: true,
          },
        },
        mensagens: {
          orderBy: {
            enviadaEm: "desc",
          },
          take: 1,
          select: {
            id: true,
            autor: true,
            direcao: true,
            tipo: true,
            conteudo: true,
            enviadaEm: true,
          },
        },
      },
      orderBy: {
        ultimaMensagemEm: "desc",
      },
    });

    const resultado = conversas.map((conversa) => {
      const ultimaMensagem = conversa.mensagens[0] ?? null;

      return {
        id: conversa.id,
        canal: conversa.canal,
        clienteId: conversa.clienteId,
        cliente: conversa.cliente,
        telefoneRemetente: conversa.telefoneRemetente,
        telefoneNormalizado: conversa.telefoneNormalizado,
        nomeExibicao: conversa.nomeExibicao,
        status: conversa.status,
        naoLidas: conversa.naoLidas,
        ativo: conversa.ativo,
        ultimaMensagemEm: conversa.ultimaMensagemEm,
        ultimaMensagem,
        createdAt: conversa.createdAt,
        updatedAt: conversa.updatedAt,
      };
    });

    return NextResponse.json(resultado);
  } catch (error) {
    console.error("Erro ao listar conversas de atendimento:", error);

    return NextResponse.json(
      {
        erro: error instanceof Error ? error.message : "Erro ao listar conversas de atendimento.",
      },
      { status: 500 }
    );
  }
}
